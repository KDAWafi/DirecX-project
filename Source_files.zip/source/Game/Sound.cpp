#include <iostream>
#include <Windows.h>
/*
using namespace std;

int main() 
{
    bool isRunning = true;

    while(isRunning)
    {
    PlaySound(TEXT("AmbientSound.wav"), NULL, SND_LOOP | SND_SYNC);
    }
    
}*/